Instructions:

Run the file "Walking3LP.m" in MATLAB 2014 or above